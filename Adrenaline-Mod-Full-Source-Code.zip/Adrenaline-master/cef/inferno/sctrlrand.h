#ifndef __SCTRLRAND_H__

/**
 * Get a random u32 key from PSP Kirk PRNG
 */
u32 sctrlKernelRand(void);

#endif /* __SCTRLRAND_H__ */
